/* global QUnit */

sap.ui.require([
	"ozak/com/zhrpersonalrequestform/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});